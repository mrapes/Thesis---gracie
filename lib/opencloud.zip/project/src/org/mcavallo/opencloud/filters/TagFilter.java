package org.mcavallo.opencloud.filters;

import org.mcavallo.opencloud.Tag;

/**
 * Tag filters base class
 */
abstract public class TagFilter extends FilterBase<Tag> {

	private static final long serialVersionUID = 1L;

}

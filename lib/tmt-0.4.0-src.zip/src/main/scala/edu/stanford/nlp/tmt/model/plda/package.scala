
package edu.stanford.nlp.tmt;
package model;

import llda.LabeledLDADocumentParams;

package object plda {
  type PLDADocumentParams = LabeledLDADocumentParams;
}


